from flask import Flask
from flask_cors import CORS
from flask_jwt_extended import JWTManager
from db import db, init_db
from auth import auth_bp

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://user:password@db:5432/auth_db'
app.config['JWT_SECRET_KEY'] = 'super-secret-key'

CORS(app)
db.init_app(app)
jwt = JWTManager(app)

app.register_blueprint(auth_bp)

@app.before_first_request
def setup():
    init_db()

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0')
